'''employees = {
    'Aryan': [82, 76, 90],
    'priya': [91, 88, 85],
    'nikhil': [55, 63, 58],
    'sunita': [70, 74, 60]
}
def get_grade(avg):
    if avg >= 80:
        return "Outstanding"
    elif 65 <= avg <= 79:
        return "Good"
    elif 50 <= avg <= 64:
        return "Average"
    else:
        return "Poor"
while True:
    print("\n--- MENU ---")
    print("1. Print employee names and ratings")
    print("2. Calculate total and average ratings")
    print("3. Update 2nd review rating")
    print("4. Display performance grade")
    print("5. Save report to file and count lines & words")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        for name, ratings in employees.items():
            print(name, ":", ratings)

    elif choice == 2:
        for name, ratings in employees.items():
            total = sum(ratings)
            avg = total / len(ratings)
            print(name, "-> Total:", total, "Average:", avg)


    elif choice == 3:
        name = input("Enter employee name: ")
        if name in employees:
            new_rating = int(input("Enter new 2nd review rating: "))
            employees[name][1] = new_rating
            print("New Ratings is: ", employees[name][1])
            print("Rating updated successfully!")

        else:
            print("Employee not found!")


    elif choice == 4:
        for name, ratings in employees.items():
            avg = sum(ratings) / len(ratings)
            grade = get_grade(avg)
            print(name, "-> Average:", avg, "Grade:", grade)


    elif choice == 5:
        file = open("performance_report.txt", "w")

        for name, ratings in employees.items():
            total = sum(ratings)
            avg = total / len(ratings)
            grade = get_grade(avg)

            line = f"{name} | Ratings: {ratings} | Total: {total} | Avg: {avg:.2f} | Grade: {grade}\n"
            file.write(line)

        file.close()

        file = open("performance_report.txt", "r")
        data = file.readlines()

        lines = len(data)
        words = 0

        for line in data:
            words += len(line.split())

        file.close()

        print("Report saved successfully!")
        print("Number of lines:", lines)
        print("Number of words:", words)

    elif choice == 6:
        print("Exiting program...")
        break

    else:
        print("Invalid choice! Please try again.")

;'''

inventory = {
    'laptop': (10, 45000),
    'mouse': (85, 350),
    'keyboard': (40, 750),
    'monitor': (6, 12000)
}

def get_stock_status(qty):
    if qty < 8:
        return "Critical Stock"
    elif 8 <= qty <= 20:
        return "Low Stock"
    elif 21 <= qty <= 50:
        return "Adequate Stock"
    else:
        return "High Stock"


while True:
    print("1. Show all items")
    print("2. Calculate stock value")
    print("3. Update item quantity")
    print("4. Show stock status")
    print("5. Save report to file")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        for item, data in inventory.items():
            qty, price = data
            print(item, qty, price)

    elif choice == 2:
        total_value = 0
        for item, data in inventory.items():
            qty, price = data
            value = qty * price
            total_value += value
            print(item, ": Stock Value:", value)
        print("Total Stock Value:", total_value)

    elif choice == 3:
        item_name = input("Enter item name: ")
        if item_name in inventory:
            new_qty = int(input("Enter new quantity: "))
            price = inventory[item_name][1]  # keep same price
            inventory[item_name] = (new_qty, price)
            print(inventory[item_name])
            print("Quantity updated successfully!")
        else:
            print("Item not found!")

    elif choice == 4:
        for item, data in inventory.items():
            qty, price = data
            status = get_stock_status(qty)
            print(item, ": Quantity:", qty, "Status:", status)

    elif choice == 5:
        file = open("store_report.txt", "w")

        for item, data in inventory.items():
            qty, price = data
            value = qty * price
            status = get_stock_status(qty)

            line = f"{item} | Qty: {qty} | Price: {price} | Value: {value} | Status: {status}\n"
            file.write(line)

        file.close()

        file = open("store_report.txt", "r")
        lines = file.readlines()

        line_count = len(lines)
        word_count = 0

        for line in lines:
            word_count += len(line.split())

        file.close()

        print("Report saved successfully!")
        print("Number of lines:", line_count)
        print("Number of words:", word_count)

    elif choice == 6:
        print("Exiting program...")
        break
    else:
        print("Invalid choice! Try again.")