'''
#second largest element in the list
nums = [10, 20, 4, 45, 99]
nums = list(set(nums))
nums.sort()
second_largest = nums[-2]
print("Second Largest:", second_largest)

#anagrams
words = ["eat", "tea", "tan", "ate", "nat", "bat"]
anagrams = {}
for word in words:
    key = ''.join(sorted(word))
    if key in anagrams:
        anagrams[key].append(word)
    else:
        anagrams[key] = [word]
for group in anagrams.values():
    print(group)

#sort a tuple bassed on 2nd element
data = [(2, 5), (1, 2), (4, 4), (2, 3)]
data.sort(key=lambda x: x[1])
print(data)

#target sum pairs
nums = (1, 2, 3, 4, 5)
target = 6
pairs = []
for i in range(len(nums)):
    for j in range(i + 1, len(nums)):
        if nums[i] + nums[j] == target:
            pairs.append((nums[i], nums[j]))
result = tuple(pairs)
print(result)

#sets intersection hunt
list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 5, 6, 7]
result = list(set(list1) & set(list2))
print("Common elements:", result)

#pangram checker
text = input("Enter a sentence: ").lower()
alphabets = set("abcdefghijklmnopqrstuvwxyz")
if alphabets <= set(text):
    print("It is a Pangram")
else:
    print("It is NOT a Pangram")
'''
#password validation checker
password = input("Enter password: ")
has_upper = False
has_lower = False
has_digit = False
has_special = False
for ch in password:
    if ch.isupper():
        has_upper = True
    elif ch.islower():
        has_lower = True
    elif ch.isdigit():
        has_digit = True
    else:
        has_special = True
if len(password) >= 8 and has_upper and has_lower and has_digit and has_special:
    print("Valid Password ")
else:
    print("Invalid Password ")

#ip address
ip = input("Enter IP address: ")
parts = ip.split(".")
if len(parts) != 4:
    print("Invalid IP")
else:
    try:
        o1, o2, o3, o4 = map(int, parts)
        if not all(0 <= x <= 255 for x in [o1, o2, o3, o4]):
            print("Invalid IP")
        elif o1 == 192 and o2 == 168:
            print("Private IP")
        elif o1 == 172 and 16 <= o2 <= 31:
            print("Private IP")
        elif o1 == 10:
            print("Private IP")
        else:
            print("Public IP")
    except:
        print("Invalid IP")