'''
#employee without menu
class Employee:
    def __init__(self, eid, ename, salary):
        self.eid = eid
        self.ename = ename
        self.salary = salary
        self.bonus = 0.10 * salary

    def calculateSal(self):
        DA = 0.10 * self.salary
        HRA = 0.15 * self.salary
        PF = 0.08 * self.salary

        net_salary = self.salary + DA + HRA - PF
        return net_salary

emplst = []

for i in range(2):
    eid = int(input("Enter ID: "))
    name = input("Enter Name: ")
    salary = float(input("Enter Salary: "))

    emp = Employee(eid, name, salary)
    emplst.append(emp)

# Display employee details
print("\nEmployee Details:")
for emp in emplst:
    print("ID:", emp.eid,
          "Name:", emp.ename,
          "Salary:", emp.salary,
          "Bonus:", emp.bonus,
          "Net Salary:", emp.calculateSal())

# Save to file
file = open("empdata.txt", "w")

for emp in emplst:
    line = f"{emp.eid}:{emp.ename}:{emp.salary}:{emp.bonus}\n"
    file.write(line)

file.close()

print("\nData saved in empdata.txt")
'''


'''
employee with menu 
class Employee:

    def __init__(self, eid, ename, salary):
        self.eid = eid
        self.ename = ename
        self.salary = salary
        self.bonus = 0.10 * salary

    def calculateSal(self):
        DA = 0.10 * self.salary
        HRA = 0.15 * self.salary
        PF = 0.08 * self.salary

        return self.salary + DA + HRA - PF

emplst = []

while True:
    print("\n--- MENU ---")
    print("1. Add Employee")
    print("2. Display Employees")
    print("3. Save to File and Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        eid = int(input("Enter ID: "))
        name = input("Enter Name: ")
        salary = float(input("Enter Salary: "))

        emp = Employee(eid, name, salary)
        emplst.append(emp)

        print("Employee added successfully!")


    elif choice == 2:
        if len(emplst) == 0:
            print("No employees found!")
        else:
            print("\nEmployee Details:")
            for emp in emplst:
                print("ID:", emp.eid,
                      "Name:", emp.ename,
                      "Salary:", emp.salary,
                      "Bonus:", emp.bonus,
                      "Net Salary:", emp.calculateSal())


    elif choice == 3:
        file = open("empdata.txt", "w")

        for emp in emplst:
            line = f"{emp.eid}:{emp.ename}:{emp.salary}:{emp.bonus}\n"
            file.write(line)

        file.close()

        print("Data saved in empdata.txt")
        print("Exiting program...")
        break

    else:
        print("Invalid choice! Try again.")
'''



'''
#book class
class Book:
    total_books = 0

    def __init__(self, title, author):
        self.title = title
        self.author = author
        self.is_available = True
        Book.total_books += 1
    def borrow_book(self):
        if self.is_available:
            self.is_available = False
            print(self.title, "borrowed successfully")
        else:
            print(self.title, "is already checked out")

    def return_book(self):
        self.is_available = True
        print(self.title, "returned successfully")


b1 = Book("Python", "Guido")
b2 = Book("Java", "James")
b3 = Book("C++", "Bjarne")

b1.borrow_book()

print("Total Books:", Book.total_books)

print("Is", b1.title, "available?", b1.is_available)'''


class Employee:
    company_name = "TechCorp"
    bonus_percentage = 5.0

    def __init__(self, name, role, base_salary):
        self.name = name
        self.role = role
        self.base_salary = base_salary

    def get_total_compensation(self):
        return self.base_salary + (self.base_salary * (Employee.bonus_percentage / 100))

e1 = Employee("Rahul", "Developer", 50000)
e2 = Employee("Priya", "Manager", 70000)

print("Before bonus change:")
print(e1.name, ":", e1.get_total_compensation())
print(e2.name, ":", e2.get_total_compensation())

Employee.bonus_percentage = 8.0

print("\nAfter bonus change:")
print(e1.name, ":", e1.get_total_compensation())
print(e2.name, ":", e2.get_total_compensation())