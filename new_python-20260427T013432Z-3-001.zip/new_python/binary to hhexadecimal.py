#binary to hexadecimal
binary = input("Enter a binary number: ")
decimal = 0
power = 0
for digit in reversed(binary):
   if digit == '1':
       decimal += 2 ** power
   power += 1
hex_digits = "0123456789ABCDEF"
hexadecimal = ""
while decimal > 0:
   remainder = decimal % 16
   hexadecimal = hex_digits[remainder] + hexadecimal
   decimal //= 16
if hexadecimal == "":
   hexadecimal = "0"
print("Hexadecimal equivalent:", hexadecimal)

#print duplicate number
total = int(input("how many values: "))
num = []
for i in range(total):
   n = int(input("enter the number: "))
   num.append(n)
print("your list is: ", num)
n = total-1
exp_sum = n*(n+1)//2
actual_sum = sum(num)
duplicate = actual_sum - exp_sum
print("duplicate number is :", duplicate)

#decimal to binary
a = int(input("Enter Decimal Number:"))
if a==0:
   print("binary of the given number is 0")
else:
   binary_str=" "
   while a > 0:
       remainder=a%2
       binary_str=str(remainder)+binary_str
       a = a//2
   print("the binary of the given ", binary_str)

#print grade
name = input("Enter your name: ")
FCN = int(input("enter your marks for FCN: "))
if FCN>100 or FCN<0:
   print("Your input is invalid")
   exit()
COSA = int(input("enter your marks for COSA: "))
if COSA>100 or COSA<0:
   print("Your input is invalid")
Pro_c = int(input("enter your marks for PC: "))
if Pro_c>100 or Pro_c<0:
   print("Your input is invalid")
a = FCN + COSA + Pro_c
if FCN ==0 or COSA ==0 or Pro_c==0:
   print("your fail")
elif a>=86 and a<=100:
   print(f"Congrats {name}! u done it (Grade : A)")
elif a>=71 and a<=85:
   print(f"{name} - Grade : B")
elif a>=56 and a<=70:
   print(f" {name} - Grade : C")
elif a>=40 and a<=55:
       print(f"{name} - Grade : D")
else:
   print(f"Sorry!{name}, Your FAIL")


#perfect number
for num in range(1, 1001):
   sum_of_divisors = 0
   for i in range(1, num):
       if num % i == 0:
           sum_of_divisors += i
   if sum_of_divisors == num:
       print(num, "is a perfect number.")


#nearest multiple of 5
num = int(input("Enter the number: "))
no =num//5
if num>5*no:
   n1=5*no
   n2=5*(no+1)
else:
   n1=5*(no-1)
   n2=5*no
d1=abs(num-n1)
d2=abs(num-n2)
if d1<d2:
   print(n1)
else:
   print(n2)
