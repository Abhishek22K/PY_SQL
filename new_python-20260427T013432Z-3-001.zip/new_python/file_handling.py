'''f = open("sample_data.txt", "r")
data = f.read()
print(data)
f.close()'''

'''
f = open("sample_data.txt", "r")
print(f.readline())
remaining_lines= f.readlines()
print(remaining_lines)
print(remaining_lines[-1])
f.close()'''


'''
with open("sample_data.txt", "a") as file:
    file.write("\nThis line was appended safely!")
'''

'''
cities = ["Tokyo\n", "Paris\n", "Cairo\n"]
file = open("travel_goals.txt", "w")
file.writelines(cities)
file.close()
'''


'''
file = open("sample_data.txt", "r")
print("Initial position:", file.tell())
data1 = file.read(15)
print("First 15 characters:", data1)
print("Position after reading 15 chars:", file.tell())
file.seek(0)
data2 = file.read(25)
print("First 25 characters after reset:", data2)
file.close()
'''

'''
#practice questions
#print the number of lines number of words and number of characters usng file handling
file = open("sample_data.txt", "r")
data = file.read()
char_count = len(data)
word_count = len(data.split())
line_count = len(data.splitlines())
print("Number of lines:", line_count)
print("Number of words:", word_count)
print("Number of characters:", char_count)
file.close()


#write a python code that will display directories and files in current working directory
import os
path = os.getcwd()
print("Current Directory:", path)
items = os.listdir(path)
print("\nFiles and Directories:")
for item in items:
    print(item)

# create 10 files at a time
import os
for i in range(1,11):
    os.system(f" type nul >python_{i}.py")


#write a python code that take path as input and  display directories and files in specified path
import os
path = input("Enter folder path: ")
if os.path.exists(path):
    items = os.listdir(path)
    for item in items:
        print(item)
else:
    print("Invalid path!")



#write a python code that will cahnge the names of every files that ends with .py as modified.py
import os
for file in os.listdir('.'):
    if file.endswith(".py"):
        for i in range(1, 11):
            os.rename(f"python_{i}.py",f"modified{i}.py")
'''


#lambda functions
#from a given list return list of odd number[lambda]
l1 = [1,6,3, 8, 29, 67, 45]
odd = list(filter(lambda x: x % 2 != 0, l1))
print(odd)

#sort a list of students bassed on their marks
students = [{"name":"ram","marks":80},
{"name":"shyam","marks":60},
{"name":"amit","marks":95}]
students.sort(key=lambda x: x["marks"])
print(students)

#sort the list of strings bassed on length of string
l1 = ["apple", "mango","kiwi","peach","banana"]
l1.sort(key=lambda x: len(x))
print(l1)

# find the numbers from list that are greater than 10 and even as well
l1 = [10,12,17,88,9,6,34,33,19,2]
l1 = list(filter(lambda x: x >10 and x%2==0, l1))
print(l1)

#print valid emails
emails=['test@gmail','user@yahoo.in','abc@outlook.com']
valid = list(filter(lambda x: '.' in x and "@" in x , emails))
print(valid)