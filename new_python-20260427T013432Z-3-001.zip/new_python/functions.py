
#parameterised function descount calculator
def calculate_discount(original_price, discount_percentage):
    discount = (discount_percentage * original_price)/100
    final_price = original_price - discount
    amount = original_price - final_price
    return final_price, amount
original_price = float(input("Enter the original price: "))
discount_percentage = float(input("Enter the discount percentage: "))
x, y = calculate_discount(original_price, discount_percentage)
print("The final price is: ", x)
print("The amount saved : ", y)


#multi return function the text analyser
def get_text_stats(string):
    wor = string.split()
    print(wor)
    word_count = len(wor)
    vow = 0
    conso = 0
    vowels = "aeiouAEIOU"
    for ch in string:
        if ch.isalpha():
            if ch in vowels:
                vow += 1
            else:
                conso += 1
    return word_count, vow, conso
text = input("Enter the your text here: ")
word_count, vowels, consonants = get_text_stats(text)
print("The word count of text is ", word_count)
print("The total no. of vowels : ", vowels)
print("The total no. of consonants : ", consonants)

#Default Parameter Function The Event Registrar:
def register_participant(name, event_name, ticket_type="General Admission"):
    return f"The ticket of type {ticket_type} is confirmed for {event_name} for the person named {name}"
data_1 = register_participant("Arjun", "BTS consort", "VVIP")
data_2 = register_participant("Riya", "Techno fest")
print(data_1)
print(data_2)

#Lambda Function The Dynamic Sorter:
employees = [{"name": "Alice", "salary": 75000}, {"name": "Bob", "salary": 54000}, {"name": "Charlie", "salary": 92000}]
sorted_employees = sorted(employees, key=lambda emp: emp["salary"], reverse=True)
print(sorted_employees)

#Combined Application The Temperature Converter (Default & Lambda):
def batch_convert_temperatures(temp_list, formula=lambda c: (c * 9/5) + 32):
    return [formula(t) for t in temp_list]
celsius_temps = [0, 25, 100]
to_fahrenheit = batch_convert_temperatures(celsius_temps)
fahrenheit_temps = [32, 77, 212]
to_celsius = batch_convert_temperatures(fahrenheit_temps, lambda f: (f - 32) * 5/9)
print(f"Celsius to Fahrenheit coversion is : {to_fahrenheit}")
print(f"Fahrenheit to Celsius conversion is : {to_celsius}")