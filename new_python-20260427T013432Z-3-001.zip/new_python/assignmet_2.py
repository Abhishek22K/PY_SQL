#basic salary gross salary
basic = float(input("Enter basic salary: "))
da = 0.75 * basic
hra = 0.20 * basic
if basic < 10000:
    gross = basic + da
elif basic >= 10000 and basic < 20000:
    gross = basic + da + (0.50 * hra)
else:
    gross = basic + da + hra
print("Gross Salary:", gross)

#factoral of the given number
num = int(input("Enter a number: "))
fact = 1
for i in range(1, num + 1):
    fact = fact * i
print("Factorial =", fact)

#addition of number between that range
num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
total = 0
for i in range(num1, num2 + 1):
    total = total + i
print("Sum =", total)

#urdu not involve
languages = ['marathi','bangla','urdu','bangla','odia','urdu',
             'kannada','bangla','tamil','kannada','marathi']
new_list = []
for lang in languages:
    if lang != 'urdu':
        new_list.append(lang)
print(new_list)

#even odd seperation
num = (56, 2, 35, 41, 43, 48, 32, 56, 71, 55, 68)
even_list = []
odd_list = []
for n in num:
    if n % 2 == 0:
        even_list.append(n)
    else:
        odd_list.append(n)
print("Even numbers:", even_list)
print("Odd numbers:", odd_list)

#even odd checker using functio
def check_even_odd(num):
    if num % 2 == 0:
        print("Even number")
    else:
        print("Odd number")
n = int(input("Enter a number: "))
check_even_odd(n)